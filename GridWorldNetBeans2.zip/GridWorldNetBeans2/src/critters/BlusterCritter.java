package critters;

import java.util.ArrayList;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class BlusterCritter extends Critter
{
int c;

public BlusterCritter(int confidence){
    c = confidence;
}

@Override
public void processActors(ArrayList<Actor> actors) {
    for (Actor a : actors)
        {
            if (!(a instanceof Rock) && !(a instanceof Critter))
                a.removeSelfFromGrid();
        }
}

@Override
public ArrayList<Actor> getActors() {
    ArrayList<Location> neighbors = new ArrayList<Location>();
    Location checkFrom = getLocation();
    int sideLength = 5;
    int steps = 0;
    int counter = 0;
for(int i = 0; i<24;i++){
    neighbors.add(checkFrom.getAdjacentLocation())
}



    return getGrid().getNeighbors(getLocation());
}

}
