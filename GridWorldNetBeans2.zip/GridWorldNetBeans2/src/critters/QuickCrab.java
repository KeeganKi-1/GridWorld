package critters;

import java.util.ArrayList;

import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public class QuickCrab extends CrabCritter {
    
    @Override
    public ArrayList<Location> getLocationsInDirections(int[] directions) {
        ArrayList<Location> locs = new ArrayList<Location>();
        Grid gr = getGrid();
        Location loc = getLocation();
    
        for (int d : directions)
        {
            Location neighborLoc = loc.getAdjacentLocation(getDirection() + d);
            Location goToLoc = neighborLoc.getAdjacentLocation(getDirection() + d);
            if(gr.get(neighborLoc) == null){
            if (gr.isValid(goToLoc))
                locs.add(goToLoc);
            }
        }
        return locs;
    }
}
